from django.contrib import admin
from .models import Detail_user

# Register your models here.
admin.site.register(Detail_user)
