from django.contrib import admin
from .models import Graphics, Animation, Robotics, WEB_Basic, UI_UX, Django, ML, C, CPP
from .models import DSA, React, Flutter, Firebase, Node, Python, IOT, Java_Android, Java, JavaScript
from .models import Flutter_firebase_dart, Deep_learning, Csharp, Game_development,BUY

# Register your models here.
admin.site.register(Graphics)
admin.site.register(Animation)
admin.site.register(Robotics)
admin.site.register(WEB_Basic)
admin.site.register(UI_UX)
admin.site.register(Django)
admin.site.register(ML)
admin.site.register(C)
admin.site.register(CPP)
admin.site.register(DSA)
admin.site.register(React)
admin.site.register(Firebase)
admin.site.register(Flutter)
admin.site.register(Node)
admin.site.register(Python)
admin.site.register(IOT)
admin.site.register(Java)

admin.site.register(Flutter_firebase_dart)
admin.site.register(Csharp)
admin.site.register(Game_development)
admin.site.register(Deep_learning)
admin.site.register(BUY)

