from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('cart/', views.cart, name='cart'),
    path('graphics/', views.graphicsdesigning, name='graphics'),
    path('animation/', views.animation, name='animation'),
    path('Robotics/', views.robotics, name='Robotics'),
    path('UI_UX/', views.ui_ux, name='UI_UX'),
    path('Webbasic/', views.webbasic, name='Mobile'),
    path('django/', views.django, name='web'),
    path('ml/', views.ml, name='Programing'),
    path('c/', views.c, name='Programing'),
    path('cpp/', views.cpp, name='Programing'),
    path('dsa/', views.dsa, name='Programing'),
    path('react/', views.react, name='Programing'),
    path('flutter/', views.flutter, name='Programing'),
    path('firebase/', views.firebase, name='Programing'),
    path('node/', views.node, name='Programing'),
    path('Python/', views.python, name='Programing'),
    path('iot/', views.iot, name='Programing'),
    path('java/', views.java, name='Programing'),
    path('javaandroid/', views.java_android, name='Programing'),
    path('javascript/', views.javascript, name='Programing'),
    path('flutter_firebase_dart/', views.firebase, name='Programing'),
    path('deeplearning/', views.deep_learning, name='Programing'),
    path('csharp/', views.csharp, name='Programing'),
    path('gamedevelopment/', views.game_development, name='Programing'),
    path('buy/', views.buy, name='buy'),
    path('learning/', views.My_Learning, name='learn'),

    path('delete/<int:id>/', views.delete_consume, name='delete')
]
