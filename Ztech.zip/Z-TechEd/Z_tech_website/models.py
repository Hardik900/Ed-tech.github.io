from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Graphics(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Graphics Designing")
    price = models.CharField(max_length=4, default="3000")


class Animation(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Animation")
    price = models.CharField(max_length=4, default="3000")
    image = models.CharField(max_length=500,
                             default='https://www.melbournefoodandwine.com.au/image-tools.php?w=560&h=440&src=/recipes/recipe-placeholder.jpg')


class IOT(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="IOT")
    price = models.CharField(max_length=4, default="3000")


class Robotics(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Robotics")
    price = models.CharField(max_length=4, default="3000")


class Flutter(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Mobile Application Development")
    price = models.CharField(max_length=4, default="3000")


class Java_Android(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Java_Android")
    price = models.CharField(max_length=4, default="3000")


class UI_UX(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="UI/UX")
    price = models.CharField(max_length=4, default="3000")


class WEB_Basic(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="WEB_Basic")
    price = models.CharField(max_length=4, default="3000")


class React(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="React")
    price = models.CharField(max_length=4, default="3000")


class Node(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Node")
    price = models.CharField(max_length=4, default="3000")


class Django(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Django")
    price = models.CharField(max_length=4, default="3000")


class C(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="C")
    price = models.CharField(max_length=4, default="3000")


class Java(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Java")
    price = models.CharField(max_length=4, default="3000")


class Python(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Python")
    price = models.CharField(max_length=4, default="3000")


class ML(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="ML")
    price = models.CharField(max_length=4, default="3000")


class JavaScript(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="JavaScript")
    price = models.CharField(max_length=4, default="3000")


class CPP(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="CPP")
    price = models.CharField(max_length=4, default="3000")


class DSA(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="DSA")
    price = models.CharField(max_length=4, default="3000")


class Firebase(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Firebase")
    price = models.CharField(max_length=4, default="3000")


class Flutter_firebase_dart(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Flutter")
    price = models.CharField(max_length=4, default="3000")


class Deep_learning(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Deep Learning")
    price = models.CharField(max_length=4, default="3000")


class Csharp(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="C#")
    price = models.CharField(max_length=4, default="3000")


class Game_development(models.Model):
    def __str__(self):
        return '%s' % (self.user)

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    coursename = models.CharField(max_length=50, default="Game Development")
    price = models.CharField(max_length=4, default="3000")


class BUY(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    allow = models.BooleanField(default=False)
    courses = models.CharField(max_length=50,default='hi',null=True)
    transection_id = models.CharField(max_length=100,default='56777')
