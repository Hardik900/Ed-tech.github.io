from django.shortcuts import render, redirect
from .models import Graphics, Animation, Robotics, WEB_Basic, UI_UX, Django, ML, C, CPP
from .models import DSA, React, Flutter, Firebase, Node, Python, IOT, Java_Android, Java, JavaScript, BUY
from django.db.models import Q


# Create your views here.

def index(request):
    return render(request, 'Z_tech_website/index.html')


def about(request):
    return render(request, 'Z_tech_website/about.html')


def cart(request):
    graphic = Graphics.objects.filter(user=request.user)
    animation = Animation.objects.filter(user=request.user)
    total = len(animation) * 3000 + len(graphic) * 3000
    context = {
        'graphic': graphic,
        'animation': animation,
        'total': total
    }
    print(len(animation))
    return render(request, 'Z_tech_website/Cart.html', context)


def delete_consume(request, id):
    # graphic = Graphics.objects.get(id=id)
    animations = Animation.objects.get(id=id)
    if request.method == 'POST':
        # graphic.delete()
        animations.delete()
        return redirect('/')
    return render(request, 'Z_tech_website/delete.html')


def graphicsdesigning(request):
    course_user = Graphics.objects.filter(user=request.user)

    if len(course_user)==1:
        if request.method == 'POST':
            course_user = Graphics(user=request.user)
            course_user.save()
        return render(request, 'Z_tech_website/graphics.html')
    else:
        print('already in cart')
        return render(request, 'Z_tech_website/Cart.html')


def animation(request):
    course_user = Graphics.objects.filter(user=request.user)

    if len(course_user) == 1:
        if request.method == 'POST':
            course_user = Animation(user=request.user)
            course_user.save()
        return render(request, 'Z_tech_website/animation.html')
    else:
        print('already in cart')
        return render(request, 'Z_tech_website/Cart.html')


def robotics(request):
    if request.method == 'POST':
        user = request.user
        course_user = Robotics(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/robotics.html')


def webbasic(request):
    if request.method == 'POST':
        user = request.user
        course_user = WEB_Basic(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/webbasic.html')


def ui_ux(request):
    if request.method == 'POST':
        user = request.user
        course_user = UI_UX(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/ui_ux.html')


def django(request):
    if request.method == 'POST':
        user = request.user
        course_user = Django(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/django.html')


def ml(request):
    if request.method == 'POST':
        user = request.user
        course_user = ML(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/ml.html')


def c(request):
    if request.method == 'POST':
        user = request.user
        course_user = C(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/c.html')


def cpp(request):
    if request.method == 'POST':
        user = request.user
        course_user = CPP(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/cpp.html')


def dsa(request):
    if request.method == 'POST':
        user = request.user
        course_user = DSA(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/dsa.html')


def react(request):
    if request.method == 'POST':
        user = request.user
        course_user = React(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/react.html')


def flutter(request):
    if request.method == 'POST':
        user = request.user
        course_user = Flutter(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/flutter.html')


def firebase(request):
    if request.method == 'POST':
        user = request.user
        course_user = Firebase(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/firebase.html')


def node(request):
    if request.method == 'POST':
        user = request.user
        course_user = Node(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/node.html')


def python(request):
    if request.method == 'POST':
        user = request.user
        course_user = Python(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/python.html')


def iot(request):
    if request.method == 'POST':
        user = request.user
        course_user = IOT(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/iot.html')


def java(request):
    if request.method == 'POST':
        user = request.user
        course_user = Java(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/java.html')


def java_android(request):
    if request.method == 'POST':
        user = request.user
        course_user = Java_Android(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/java_android.html')


def javascript(request):
    if request.method == 'POST':
        user = request.user
        course_user = JavaScript(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/javascript.html')


def fluttet_firebase_dart(request):
    if request.method == 'POST':
        user = request.user
        course_user = JavaScript(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/flutter_firebase.html')


def deep_learning(request):
    if request.method == 'POST':
        user = request.user
        course_user = JavaScript(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/deeplearning.html')


def csharp(request):
    if request.method == 'POST':
        user = request.user
        course_user = JavaScript(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/csharp.html')


def game_development(request):
    if request.method == 'POST':
        user = request.user
        course_user = JavaScript(user=request.user)
        course_user.save()
    return render(request, 'Z_tech_website/game_development.html')


def buy(request):
    if request.method == 'POST':
        field_name = 'coursename'
        obj = Animation.objects.first()
        field_object = Animation._meta.get_field(field_name)
        field_value = field_object.value_from_object(obj)
        print(field_value)

        customer = BUY(user=request.user)

        customer.courses = field_value
        customer.transection_id = request.POST.get('transection_id')
        customer.save()
    return render(request, 'Z_tech_website/buy_now.html')


def My_Learning(request):

    x=BUY.objects.filter(allow=True)
    print(x)
    return render(request,'Z_tech_website/learning.html')

