from django.apps import AppConfig


class ZTechWebsiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Z_tech_website'
