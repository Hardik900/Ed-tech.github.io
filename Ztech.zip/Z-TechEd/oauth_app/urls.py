from django.urls import include, path
from .views import account_signup_view

urlpatterns = [

    # override the SignupView of django-allauth
    path("signup/", view=account_signup_view,name='signup'),
    # this is the default config for django-allauth
    path("accounts/", include("allauth.urls")),

]