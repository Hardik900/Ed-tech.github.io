from django.apps import AppConfig


class ZTechWebsiteConfig(AppConfig):
    name = 'Z_tech_website'
